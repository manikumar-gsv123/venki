package com.aem.demo.core.schedulers;

import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowData;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;



@Component(service= WorkflowProcess.class,property = {"process.label=venkyf"})

public class venkyflow implements WorkflowProcess{
	
	@Reference
	ResourceResolverFactory  rrf;

	@Override
	public void execute(WorkItem witem, WorkflowSession wsession, MetaDataMap arg2) throws WorkflowException {
		// TODO Auto-generated method stub
		
		
		try {
		Map<String, Object> paramp = new HashMap<String, Object>();
		paramp.put(ResourceResolverFactory.SUBSERVICE, "myservicetest");
		
		
		WorkflowData data = witem.getWorkflowData();
		 
		String payload = (String) data.getPayload();
		
		
			ResourceResolver resourceresolver = rrf.getServiceResourceResolver(paramp);
			Resource resource = resourceresolver.getResource(payload);
			Node node = resource.adaptTo(Node.class);
			Node jcrnode=node.getNode("jcr:content");
			jcrnode.setProperty("sankar", "workflow");
			jcrnode.setProperty("sankar1", "workflow1");
		node.getSession().save();
			
			
			
			
		} catch (LoginException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PathNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
	}

}

/*
 * package com.aem.demo.core.servlets; { import java.io.IOException; import
 * javax.servlet.Servlet; import org.apache.sling.api.SlingHttpServletResponse;
 * import org.apache.sling.api.servlets.SlingSafeMethodsServlet; import
 * org.osgi.framework.Constants; import
 * org.osgi.service.component.annotations.Component;
 * 
 * @Component(service = Servlet.class, property = {
 * Constants.SERVICE_DESCRIPTION + "=Simple Demo Servlet",
 * "sling.servlet.methods=" + HttpConstants.METHOD_GET, "sling.servlet.paths=" +
 * "/bin/servlet", "sling.servlet.extensions=" + "sample", })
 * 
 * public class ResolveServletUsingPath extends SlingSafeMethodsServlet{
 * 
 * @Override protected void doGet(SlingHttpServlet
 * request,SlingHttpServletResponse response) throws IOException{
 * 
 * } } } }
 */
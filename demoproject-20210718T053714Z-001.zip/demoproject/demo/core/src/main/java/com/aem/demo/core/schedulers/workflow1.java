/*
 * package com.aem.demo.core.schedulers;
 * 
 * import org.osgi.service.component.annotations.Component; import
 * org.slf4j.Logger; import org.slf4j.LoggerFactory;
 * 
 * import com.day.cq.workflow.WorkflowException; import
 * com.day.cq.workflow.WorkflowSession; import
 * com.day.cq.workflow.exec.WorkItem; import
 * com.day.cq.workflow.exec.WorkflowData; import
 * com.day.cq.workflow.exec.WorkflowProcess; import
 * com.day.cq.workflow.metadata.MetaDataMap;
 * 
 * import jdk.internal.org.jline.utils.Log;
 * 
 * @Component(service = workflow1.class,property =
 * {"process.label = kumarworkflow "})
 * 
 * public class workflow1 implements WorkflowProcess {
 * 
 * private final Logger log = LoggerFactory.getLogger(this.getClass());
 * 
 * @Override public void execute(WorkItem item, WorkflowSession session,
 * MetaDataMap arg2) throws WorkflowException { // TODO Auto-generated method
 * stub
 * 
 * WorkflowData data = item.getWorkflowData();
 * 
 * String payload = (String) data.getPayload();
 * 
 * Log.info("from the workflow"); Log.info(payload);
 * 
 * 
 * }
 * 
 * }
 */